%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% File     : alarm_logger.erl
%%% Author   : <trainers@erlang-solutions.com>
%%% Copyright: 1999-2017 Erlang Solutions Ltd.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(alarm_logger).
-vsn('1.0').
-behaviour(gen_event).

%% Callback API for the gen_event
-export([init/1,
         handle_event/2,
         handle_call/2,
         handle_info/2,
         terminate/2]).

-record(state, {stream}).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXPORTED FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

init(_Arg) ->
    PrivDir = code:priv_dir(ebank_frontend),
    {ok, Stream} = file:open(filename:join([PrivDir, "EbankLog.txt"]), [write]),
    {ok, #state{stream = Stream}}.


handle_event({set_alarm, Alarm}, State) ->
    io:format(State#state.stream, "Set ~p~n", [Alarm]),
    {ok, State};
handle_event({clear_alarm, Alarm}, State) ->
    io:format(State#state.stream, "Clear ~p~n", [Alarm]),
    {ok, State};
handle_event(_, State) ->
    {ok, State}.

handle_call(_Query, State) ->
    {ok, undefined, State}.

handle_info(_Info, State) ->
    {ok, State}.

terminate(swap, _State) ->
    {alarm_handler, ok};
terminate(_Arg, State) ->
    file:close(State#state.stream).
