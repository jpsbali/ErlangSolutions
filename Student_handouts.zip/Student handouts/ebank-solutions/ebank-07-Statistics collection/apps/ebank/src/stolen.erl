%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% File     : stolen.erl
%%% Author   : <trainers@erlang-solutions.com>
%%% Copyright: 1999-2017 Erlang Solutions Ltd.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(stolen).
-vsn('1.0').
-behaviour(gen_event).

%% Callback API for the gen_event
-export([init/1,
         handle_event/2,
         handle_call/2,
         handle_info/2,
         terminate/2]).

-record(state, {suspicious}).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXPORTED FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

init(_Arg) ->
    TableName = ets:new(suspicious, [named_table, set]),
    {ok, #state{suspicious = TableName}}.


handle_event({valid_pin, AccNo}, #state{suspicious = Table} = State) ->
    ets:delete(Table, AccNo),
    {ok, State};
handle_event({invalid_pin, AccNo}, #state{suspicious = Table} = State) ->
    case ets:update_counter(Table, AccNo, 1, {AccNo, 0}) of
        N when N < 3 ->
            do_nothing;
        _Else ->
            backend:block(AccNo)
    end,
    {ok, State};
handle_event({account_unblocked, AccNo}, #state{suspicious = Table} = State) ->
    ets:delete(Table, AccNo),
    {ok, State};
handle_event(_, State) ->
    {ok, State}.

handle_call(_Query, State) ->
    {ok, undefined, State}.

handle_info(_Info, State) ->
    {ok, State}.

terminate(_Arg, State) ->
    ets:delete(State#state.suspicious).
