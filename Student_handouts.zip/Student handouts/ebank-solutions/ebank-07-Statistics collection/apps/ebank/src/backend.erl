%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% File     : backend.erl
%%% Author   : <trainers@erlang-solutions.com>
%%% Copyright: 1999-2017 Erlang Solutions Ltd.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(backend).
-behaviour(gen_server).

%% Public API
-export([start_link/0,
         stop/0,
         account/1,
         accounts_by_name/1,
         list_accounts/0,
         pin_valid/2,
         balance/2,
         transactions/2,
         withdraw/3,
         deposit/2,
         transfer/4,
         block/1,
         unblock/1]).

%% Callback API for the gen_server
-export([init/1,
         handle_call/3,
         handle_cast/2,
         handle_info/2,
         terminate/2,
         code_change/3
        ]).

-include_lib("ebank/include/backend.hrl").

-define(SERVER, ?MODULE).

-record(state, {account_table}).

%% Test accounts used throughout the exercises
-define(ACCOUNTS,
        [{1, 100, "1234", "Henry Nystrom"},
         {2, 200, "4321", "Francesco Cesarini"},
         {3, 1000, "1111", "Donald Duck"},
         {4, 5000, "1234", "Henry Nystrom"}
        ]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% EXPORTED FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Start the backend server.
-spec start_link() -> {ok, pid()} | {error, Reason :: term()}.
start_link() ->
    gen_server:start_link({local, ?SERVER}, ?MODULE, no_args, []).

%% Stop the backend server.
-spec stop() -> ok.
stop() ->
    gen_server:call(?SERVER, stop).

%% Retrieve the account informations by the account number.
-spec account(backend_db:account_number()) -> #account{} | {error, Reason :: term()}.
account(AccNo) ->
    gen_server:call(?SERVER, {account_by_number, AccNo}).

%% Retrieve all accounts for a person. Only used by the WEB interface, so we
%% don't need to validate the PIN.
-spec accounts_by_name(backend_db:name()) -> [#account{}].
accounts_by_name(Name) ->
    gen_server:call(?SERVER, {accounts_by_name, Name}).

%% List all accounts. Only used by the ATM interface, so that we can provide a
%% list of cards to be used.
-spec list_accounts() -> [#account{}].
list_accounts() ->
    gen_server:call(?SERVER, {list_accounts}).

%% Verify the validity of the PIN for an account.
-spec pin_valid(backend_db:account_number(), backend_db:pin()) -> boolean() | {error, Reason :: term()}.
pin_valid(AccNo, Pin) ->
    gen_server:call(?SERVER, {pin_valid, AccNo, Pin}).

%% Withdraw Amount from an account. Used by the WebATM. We verify the validity
%% of the PIN.
-spec withdraw(backend_db:account_number(), backend_db:pin(), backend_db:amount()) -> ok | {error, Reason :: term()}.
withdraw(AccNo, Pin, Amount) ->
    gen_server:call(?SERVER, {withdraw, AccNo, Pin, Amount}).

%% Deposits money on an account. No PIN validation is required. Money laundering
%% prevention is out of scope.
-spec deposit(backend_db:account_number(), backend_db:amount()) -> ok | {error, Reason :: term()}.
deposit(AccNo, Amount) ->
    gen_server:call(?SERVER, {deposit, AccNo, Amount}).

%% Transfers the amount to the target account from the source account. We verify
%% that the PIN is valid for the source account.
-spec transfer(backend_db:account_number(), backend_db:account_number(), backend_db:amount(), backend_db:pin()) -> ok | {error, Reason :: term()}.
transfer(FromAccNo, ToAccNo, Amount, Pin) ->
    gen_server:call(?SERVER, {transfer, FromAccNo, ToAccNo, Amount, Pin}).

%% Return the current balance for the account after verifying the PIN.
-spec balance(backend_db:account_number(), backend_db:pin()) -> backend_db:balance() | {error, Reason :: term()}.
balance(AccNo, Pin) ->
    gen_server:call(?SERVER, {balance, AccNo, Pin}).

%% Return the transaction history of the account after verifying the PIN.
-spec transactions(backend_db:account_number(), backend_db:pin()) -> backend_db:transactions() | {error, Reason :: term()}.
transactions(AccNo, Pin) ->
    gen_server:call(?SERVER, {transactions, AccNo, Pin}).

%% Blocks an account because of suspicion of theft.
-spec block(backend_db:account_number()) -> ok.
block(AccNo) ->
    gen_server:cast(?SERVER, {block, AccNo}).

%% Unblocks an account because of suspicion of theft.
-spec unblock(backend_db:account_number()) -> ok.
unblock(AccNo) ->
    gen_server:cast(?SERVER, {unblock, AccNo}).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CALLBACK API FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

init(no_args) ->
    process_flag(trap_exit, true),
    DbRef = backend_db:create_db(),
    lists:foreach(
      fun({AccNo, Balance, Pin, Name}) ->
              backend_db:new_account(AccNo, Pin, Name, DbRef),
              backend_db:credit(AccNo, Balance, DbRef)
      end, ?ACCOUNTS),
    {ok, #state{account_table = DbRef}}.

handle_call({account_by_number, AccNo}, _From, #state{account_table=DbRef} = State) ->
    Result = case backend_db:lookup(AccNo, DbRef) of
                 {error, instance} ->
                     {error, "No accounts for the account number"};
                 Account ->
                     Account
             end,
    {reply, Result, State};

handle_call({accounts_by_name, Name}, _From, #state{account_table=DbRef} = State) ->
    Result = backend_db:lookup_by_name(Name, DbRef),
    {reply, Result, State};

handle_call({list_accounts}, _From, #state{account_table=DbRef} = State) ->
    Result = backend_db:all_accounts(DbRef),
    {reply, Result, State};

handle_call({pin_valid, AccNo, Pin}, _From, #state{account_table=DbRef} = State) ->
    Result = backend_db:is_pin_valid(AccNo, Pin, DbRef),
    case Result of
        true ->
            event_manager:notify({valid_pin, AccNo});
        false ->
            event_manager:notify({invalid_pin, AccNo})
    end,
    {reply, Result, State};

handle_call({withdraw, AccNo, Pin, Amount}, _From, #state{account_table=DbRef} = State) ->
    Result =
        case backend_db:is_pin_valid(AccNo, Pin, DbRef) of
            true ->
                event_manager:notify({valid_pin, AccNo}),
                event_manager:notify({withdraw, Amount}),
                backend_db:debit(AccNo, Amount, DbRef);
            false ->
                event_manager:notify({invalid_pin, AccNo}),
                {error, "Invalid PIN"}
        end,
    {reply, Result, State};

handle_call({deposit, AccNo, Amount}, _From, #state{account_table=DbRef} = State) ->
    event_manager:notify({deposit, Amount}),
    Result = backend_db:credit(AccNo, Amount, DbRef),
    {reply, Result, State};


handle_call({transfer, FromAccNo, ToAccNo, Amount, Pin}, _From, #state{account_table=DbRef} = State) ->
    Result =
        case backend_db:is_pin_valid(FromAccNo, Pin, DbRef) of
            true ->
                event_manager:notify({valid_pin, FromAccNo}),
                event_manager:notify({transfer, Amount}),
                case backend_db:debit(FromAccNo, Amount, DbRef) of
                    {error, _Reason} = Error ->
                        Error;
                    _Success ->
                        backend_db:credit(ToAccNo, Amount, DbRef)
                end;
            false ->
                event_manager:notify({invalid_pin, FromAccNo}),
                {error, "Invalid PIN"}
        end,
    {reply, Result, State};

handle_call({balance, AccNo, Pin}, _From, #state{account_table=DbRef} = State) ->
    Result =
        case backend_db:is_pin_valid(AccNo, Pin, DbRef) of
            true ->
                %% No need to check for the existence of the account, it's been
                %% checked by the PIN check
                #account{balance = Balance} = backend_db:lookup(AccNo, DbRef),
                Balance;
            false ->
                {error, "Invalid PIN"}
        end,
    {reply, Result, State};


handle_call({transactions, AccNo, Pin}, _From, #state{account_table=DbRef} = State) ->
    Result =
        case backend_db:is_pin_valid(AccNo, Pin, DbRef) of
            true ->
                %% No need to check for the existence of the account, it's been
                %% checked by the PIN check
                #account{transactions = Transactions} = backend_db:lookup(AccNo, DbRef),
                Transactions;
            false ->
                {error, "Invalid PIN"}
        end,
    {reply, Result, State};

handle_call(stop, _From, State) ->
    {stop, normal, ok, State}.


handle_cast({block, AccNo}, #state{account_table=DbRef} = State) ->
    event_manager:notify({account_blocked, AccNo}),
    backend_db:block(AccNo, DbRef),
    {noreply, State};

handle_cast({unblock, AccNo}, #state{account_table=DbRef} = State) ->
    event_manager:notify({account_unblocked, AccNo}),
    backend_db:unblock(AccNo, DbRef),
    {noreply, State};

handle_cast(Cast, State) ->
    {stop, {"Can not handle cast", Cast}, State}.


handle_info(Info, State) ->
    {stop, {"Can not handle info", Info}, State}.


terminate(_Reason, #state{account_table=DbRef} = _State) ->
    backend_db:close(DbRef).

code_change(_, State, _) ->
    {ok, State}.
