%%%-------------------------------------------------------------------
%% @doc ebank top level supervisor.
%% @end
%%%-------------------------------------------------------------------

-module(ebank_sup).

-behaviour(supervisor).

%% API
-export([start_link/0,
         start_atm/2,
         stop_atm/1]).

%% Supervisor callbacks
-export([init/1]).

-define(SERVER, ?MODULE).

%%====================================================================
%% API functions
%%====================================================================

start_link() ->
    supervisor:start_link({local, ?SERVER}, ?MODULE, []).

start_atm(Name, Port) ->
    supervisor:start_child(?SERVER, atm_sup(Name, Port)).

stop_atm(Name) ->
    supervisor:terminate_child(?SERVER, {atm_sup, Name}),
    supervisor:delete_child(?SERVER, {atm_sup, Name}).


%%====================================================================
%% Supervisor callbacks
%%====================================================================

%% Child :: #{id => Id, start => {M, F, A}}
%% Optional keys are restart, shutdown, type, modules.
%% Before OTP 18 tuples must be used to specify a child. e.g.
%% Child :: {Id,StartFunc,Restart,Shutdown,Type,Modules}
init([]) ->
    {ok, {#{strategy => rest_for_one,
            intensity => 5,
            period => 2000},
          [backend(), web(), default_atm()]}}.

%%====================================================================
%% Internal functions
%%====================================================================

backend() ->
    #{id => backend,
      start => {backend, start_link, []},
      restart => permanent,
      shutdown => brutal_kill,
      type => worker,
      modules => [backend]}.

web() ->
    #{id => web,
      start => {web, start_link, []},
      restart => permanent,
      shutdown => brutal_kill,
      type => worker,
      modules => [web]}.

default_atm() ->
    atm_sup(atm1, 8081).

atm_sup(Name, Port) ->
    #{id => {atm_sup, Name},
      start => {atm_sup, start_link, [Name, Port]},
      restart => permanent,
      shutdown => brutal_kill,
      type => supervisor,
      modules => [atm_sup]}.
