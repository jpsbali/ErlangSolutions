%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% File     : atm.erl
%%% Author   : <trainers@erlang-solutions.com>
%%% Copyright: 1999-2018 Erlang Solutions Ltd.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(atm).
-behaviour(gen_statem).

%% Public API
-export([start/1,
         start_link/1,
         stop/1,
         card_inserted/2,
         event/2]).

%% Callback API for the gen_statem
-export([init/1,
         callback_mode/0,
         terminate/3,
         code_change/4]).

%% Callback functions for the states
-export([idle/3,
         get_pin/3,
         selection/3,
         withdraw/3]).

-record(state, {name,
                accountNo,
                input = [],
                pin}).

-type event() :: {selection, atom()} | atom().

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% EXPORTED FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-spec start(atom()) -> {ok, pid()} | {error, Reason::term()}.
start(Name) -> gen_statem:start({global, {?MODULE, Name}}, ?MODULE, Name, []).

-spec start_link(atom()) -> {ok, pid()} | {error, Reason::term()}.
start_link(Name) ->
    gen_statem:start_link({global, {?MODULE, Name}}, ?MODULE, Name, []).

-spec stop(atom()) -> ok.
stop(Name) -> gen_statem:cast({global, {?MODULE, Name}}, stop).

-spec event(atom(), event()) -> ok.
event(Name, E) -> gen_statem:cast({global, {?MODULE, Name}}, E).

-spec card_inserted(atom(), backend:accountNo()) -> ok.
card_inserted(Name, Account) -> event(Name, {card_inserted, Account}).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CALLBACK API FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-spec init(atom()) -> {ok, atom(), #state{}}.
init(Name) ->
    {ok, idle, #state{name = Name}}.


-spec callback_mode() -> state_functions | handle_event_function.
callback_mode() -> state_functions.


idle(cast, {card_inserted, AccountNumber}, #state{name = Name}) ->
    webatm:show_pin_request(Name),
    {next_state, get_pin, #state{name = Name, accountNo = AccountNumber}};

idle(cast, clear, #state{name = Name} = State) ->
    webatm:clear(Name),
    {keep_state, State#state{input = []}};

idle(cast, cancel, #state{name=Name}) ->
    webatm:cancel(Name),
    {next_state, idle, #state{name=Name}};

idle(cast, {digit, _}, State) ->
    {keep_state, State};

idle(cast, {selection, _}, State) ->
    {keep_state, State};

idle(cast, enter, State) ->
    {keep_state, State};

idle(cast, stop, State) ->
    {stop, normal, State};

idle({call,_From}, Event, State) ->
    {stop, {"Cannot handle sync event", Event}, State};

idle(info, Event, State) ->
    {stop, {"Cannot handle info", Event}, State}.



get_pin(cast, clear, #state{name = Name} = State) ->
    webatm:clear(Name),
    {keep_state, State#state{input = []}};

get_pin(cast, cancel, #state{name=Name}) ->
    webatm:cancel(Name),
    {next_state, idle, #state{name=Name}};

get_pin(cast, {digit, Digit}, State = #state{name=Name}) ->
    Digits = State#state.input ++ Digit,
    webatm:show_input(Name, Digits),
    {keep_state, State#state{input = Digits}};

get_pin(cast, enter, State = #state{name = Name, accountNo = AccountNo, input=Input}) ->
    case backend:pin_valid(AccountNo, Input) of
        true ->
            webatm:show_pin_valid_message(Name),
            {next_state, selection, State#state{pin = Input, input = []}};
        false ->
            webatm:show_pin_invalid_message(Name),
            {keep_state, State#state{input = []}}
    end;

get_pin(cast, {selection, _}, State) ->
    {keep_state, State};

get_pin(cast, {card_inserted, _}, State) ->
    {keep_state, State};

get_pin(cast, stop, State) ->
    {stop, normal, State};

get_pin({call,_From}, Event, State) ->
    {stop, {"Cannot handle sync event", Event}, State};

get_pin(info, Event, State) ->
    {stop, {"Cannot handle info", Event}, State}.



selection(cast, clear, #state{name = Name} = State) ->
    webatm:clear(Name),
    {keep_state, State#state{input = []}};

selection(cast, cancel, #state{name=Name}) ->
    webatm:cancel(Name),
    {next_state, idle, #state{name=Name}};

selection(cast, {selection, withdraw}, State = #state{name=Name}) ->
    webatm:show_withdraw_message(Name),
    {next_state, withdraw, State};

selection(cast, {selection, balance}, State = #state{name=Name, accountNo = No, pin = Pin}) ->
    Balance = backend:balance(No, Pin),
    webatm:show_balance(Name, Balance),
    {keep_state, State};

selection(cast, {selection, statement}, State = #state{name=Name, accountNo = No, pin = Pin}) ->
    Balance = backend:balance(No, Pin),
    Transactions = backend:transactions(No, Pin),
    webatm:show_mini_statement(Name, Transactions, Balance),
    {keep_state, State};

selection(cast, {digit, _}, State) ->
    {keep_state, State};

selection(cast, enter, State) ->
    {keep_state, State};

selection(cast, {card_inserted, _}, State) ->
    {keep_state, State};

selection(cast, stop, State) ->
    {stop, normal, State};

selection({call,_From}, Event, State) ->
    {stop, {"Cannot handle sync event", Event}, State};

selection(info, Event, State) ->
    {stop, {"Cannot handle info", Event}, State}.



withdraw(cast, clear, #state{name = Name} = State) ->
    webatm:clear(Name),
    {keep_state, State#state{input = []}};

withdraw(cast, cancel, #state{name=Name}) ->
    webatm:cancel(Name),
    {next_state, idle, #state{name=Name}};

withdraw(cast, {digit, Digit}, State = #state{name=Name}) ->
    Input = State#state.input ++ Digit,
    webatm:show_input(Name, Input),
    {keep_state, State#state{input = Input}};

withdraw(cast, enter, #state{name=Name, accountNo=AccNo, pin=Pin, input=Input}) ->
    case backend:withdraw(AccNo, Pin, list_to_integer(Input)) of
        ok ->
            webatm:show_successful_withdraw(Name);
        {error, Reason} ->
            io:format("fail: ~p~n", [Reason]),
            webatm:show_unsuccessful_withdraw(Name, Reason)
    end,
    %% Simulate some slowness to present the money or the error message
    timer:sleep(3500),
    {next_state, idle, #state{name = Name}};

withdraw(cast, {selection, _}, State) ->
    {keep_state, State};

withdraw(cast, {card_inserted, _}, State) ->
    {keep_state, State};

withdraw(cast, stop, State) ->
    {stop, normal, State};

withdraw({call,_From}, Event, State) ->
    {stop, {"Cannot handle sync event", Event}, State};

withdraw(info, Event, State) ->
    {stop, {"Cannot handle info", Event}, State}.




code_change(_, StateName, State, _) -> {ok, StateName, State}.



terminate(_, _, _) -> ok.
