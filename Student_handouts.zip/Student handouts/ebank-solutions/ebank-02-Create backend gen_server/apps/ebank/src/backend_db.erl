%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% File     : backend.erl
%%% Author   : <trainers@erlang-solutions.com>
%%% Copyright: 1999-2017 Erlang Solutions Ltd.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(backend_db).

-export([create_db/0,
         new_account/4,
         lookup/2,
         lookup_by_name/2,
         credit/3,
         debit/3,
         close/1,
         is_pin_valid/3,
         all_accounts/1
        ]).

-type dbref() :: ets:tab().
-type account_number() :: pos_integer().
-type pin() :: string().
-type name() :: string() | binary().
-type amount() :: number().
-type balance() :: amount().
-type transaction() :: {credit | debit, calendar:datetime(), amount()}.
-type transactions() :: list(transaction()).

-include_lib("ebank/include/backend.hrl").


%% Creates an empty DB.
-spec create_db() -> dbref().
create_db() ->
    ets:new(accounts, [set, named_table, public, {keypos, #account.acc_no}]).

%% Look up an account record by the account number.
-spec lookup(account_number(), dbref()) -> #account{} | {error, instance}.
lookup(AccNo, DbRef) ->
    case ets:lookup(DbRef, AccNo) of
        [] ->
            {error, instance};
        [Account] ->
            Account
    end.

%% Look up accounts belonging to the same person.
-spec lookup_by_name(name(), dbref()) -> [#account{}].
lookup_by_name(Name, DbRef) ->
    ets:select(DbRef, [{#account{name = Name, _ = '_'}, [], ['$_']}]).

%% Adds a new account to the DB.
-spec new_account(account_number(), pin(), name(), dbref()) -> ok | {error, exists}.
new_account(AccNo, Pin, Name, DbRef) ->
    case lookup(AccNo, DbRef) of
        {error, instance} ->
            ets:insert(DbRef, #account{acc_no = AccNo,
                                       pin = Pin,
                                       name = Name}),
            ok;
        _Account ->
            {error, exists}
    end.

%% Credit the account with the specified amount
-spec credit(account_number(), amount(), dbref()) -> ok | {error, instance} | {error, string()}.
credit(AccNo, Amount, DbRef) ->
    case lookup(AccNo, DbRef) of
        {error, instance} ->
            {error, instance};
        Account = #account{balance = OldBalance,
                           transactions = OldTransactions} ->
            NewAccount = Account#account{balance = OldBalance + Amount,
                                         transactions = [{credit, calendar:local_time(), Amount} | OldTransactions]},
            ets:insert(DbRef, NewAccount),
            ok
    end.

%% Debit the account with the specified amount
-spec debit(account_number(), amount(), dbref()) -> ok | {error, instance} | {error, string()}.
debit(AccNo, Amount, DbRef) ->
    case lookup(AccNo, DbRef) of
        {error, instance} ->
            {error, instance};
        Account = #account{balance = OldBalance,
                           transactions = OldTransactions} ->
            case OldBalance < Amount of
                true ->
                    {error, balance};
                false ->
                    NewAccount = Account#account{balance = OldBalance - Amount,
                                                 transactions = [{debit, calendar:local_time(), Amount} | OldTransactions]},
                    ets:insert(DbRef, NewAccount),
                    ok
            end
    end.

%% Deletes the DB.
-spec close(dbref()) -> ok.
close(DbRef) ->
    ets:delete(DbRef),
    ok.

%% Validates the PIN
-spec is_pin_valid(account_number(), pin(), dbref()) -> #account{}.
is_pin_valid(AccNo, Pin, DbRef) ->
    case lookup(AccNo, DbRef) of
        {error, instance} ->
            false;
        Account ->
            Account#account.pin =:= Pin
    end.

%% List all accounts
-spec all_accounts(dbref()) -> [#account{}].
all_accounts(DbRef) ->
    ets:tab2list(DbRef).
