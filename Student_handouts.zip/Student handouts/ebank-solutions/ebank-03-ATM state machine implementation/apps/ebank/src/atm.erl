%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% File     : atm.erl
%%% Author   : <trainers@erlang-solutions.com>
%%% Copyright: 1999-2018 Erlang Solutions Ltd.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(atm).
-behaviour(gen_statem).

%% Public API
-export([start/1,
         start_link/1,
         stop/1,
         card_inserted/2,
         event/2]).

%% Callback API for the gen_statem
-export([init/1,
         callback_mode/0,
         terminate/3,
         code_change/4]).

%% Callback functions for the states
-export([idle/3,
         get_pin/3,
         selection/3,
         withdraw/3]).

-record(state, {name,
                accountNo,
                input = [],
                pin}).

-type event() :: {selection, atom()} | atom().

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% EXPORTED FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-spec start(atom()) -> {ok, pid()} | {error, Reason::term()}.
start(Name) -> gen_statem:start({global, {?MODULE, Name}}, ?MODULE, Name, []).

-spec start_link(atom()) -> {ok, pid()} | {error, Reason::term()}.
start_link(Name) ->
    gen_statem:start_link({global, {?MODULE, Name}}, ?MODULE, Name, []).

-spec stop(atom()) -> ok.
stop(Name) -> gen_statem:cast({global, {?MODULE, Name}}, stop).

-spec event(atom(), event()) -> ok.
event(Name, E) -> gen_statem:cast({global, {?MODULE, Name}}, E).

-spec card_inserted(atom(), backend:accountNo()) -> ok.
card_inserted(Name, Account) -> event(Name, {card_inserted, Account}).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CALLBACK API FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-spec init(atom()) -> {ok, atom(), #state{}}.
init(Name) ->
    {ok, idle, #state{name = Name}}.


-spec callback_mode() -> state_functions | handle_event_function.
callback_mode() -> state_functions.


idle(cast, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

idle({call,_From}, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

idle(info, _Event, Data) ->
    {stop, {error, not_implemented}, Data}.


get_pin(cast, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

get_pin({call,_From}, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

get_pin(info, _Event, Data) ->
    {stop, {error, not_implemented}, Data}.


selection(cast, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

selection({call,_From}, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

selection(info, _Event, Data) ->
    {stop, {error, not_implemented}, Data}.


withdraw(cast, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

withdraw({call,_From}, _Event, Data) ->
    {stop, {error, not_implemented}, Data};

withdraw(info, _Event, Data) ->
    {stop, {error, not_implemented}, Data}.



code_change(_, StateName, Data, _) -> {ok, StateName, Data}.



terminate(_, _, _) -> ok.
