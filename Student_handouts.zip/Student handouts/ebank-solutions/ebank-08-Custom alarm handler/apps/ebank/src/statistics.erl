%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% File     : thieves.erl
%%% Author   : <trainers@erlang-solutions.com>
%%% Copyright: 1999-2017 Erlang Solutions Ltd.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-module(statistics).
-vsn('1.0').
-behaviour(gen_event).

%% Callback API for the gen_event
-export([init/1,
         handle_event/2,
         handle_call/2,
         handle_info/2,
         terminate/2]).

-record(state, {statistics}).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXPORTED FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

init(_Arg) ->
    TableName = ets:new(statistics, [set, named_table]),
    {ok, #state{statistics = TableName}}.


handle_event({withdraw, Amount}, #state{statistics = Table} = State) ->
    update(Table, withdraw_count, 1),
    update(Table, reserves, -Amount),
    {ok, State};
handle_event({deposit, Amount}, #state{statistics = Table} = State) ->
    update(Table, deposit_count, 1),
    update(Table, reserves, Amount),
    {ok, State};
handle_event({transfer, Amount}, #state{statistics = Table} = State) ->
    NewTransferCount = update(Table, transfer_count, 1),
    NewTotalTransfer = update(Table, total_transfer_amount, Amount),
    AvgTransferAmount = NewTotalTransfer / NewTransferCount,
    ets:insert(Table, {avg_transfer_amount, AvgTransferAmount}),
    {ok, State};
handle_event({account_blocked, _AccNo}, #state{statistics = Table} = State) ->
    update(Table, block_count, 1),
    {ok, State};
handle_event({account_unblocked, _AccNo}, #state{statistics = Table} = State) ->
    update(Table, unblock_count, 1),
    {ok, State};
handle_event(_, State) ->
    {ok, State}.

handle_call(get_stats, #state{statistics = Table} = State) ->
    StatList = ets:tab2list(Table),
    {ok, StatList, State}.

handle_info(_Info, State) ->
    {ok, State}.

terminate(_Arg, State) ->
    ets:delete(State#state.statistics).

update(Table, Key, Value) ->
    ets:update_counter(Table, Key, Value, {Key, 0}).
