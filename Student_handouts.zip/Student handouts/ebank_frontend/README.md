ebank_frontend
=====

The web frontend for the ebank application. This should be pulled as a
dependency and the corresponding backend should be implemented for all
functionality to work.

Build
-----

    $ rebar3 compile
