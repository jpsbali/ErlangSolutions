%%%=============================================================================
%%% @copyright 2019, Erlang Solutions Ltd
%%% @doc Additional unit tests for the ebank backend.
%%% @end
%%%=============================================================================
-module(backend_extra_tests).
-copyright("2019, Erlang Solutions Ltd.").

-include_lib("eunit/include/eunit.hrl").
-include_lib("ebank/include/backend.hrl").

block_unblock_test() ->
    register(alarm_handler, self()), %% dummy alarm_handler to prevent crash
    {ok, Pid} = backend:start_link(),
    ?assert(is_pid(Pid)),
    AccNo = 1,
    Pin = "1234",
    ?assertMatch(#account{blocked = false}, backend:account(AccNo)),
    ?assertEqual(true, backend:pin_valid(AccNo, Pin)),
    ?assertEqual(ok, backend:block(AccNo)),
    ?assertMatch(#account{blocked = true}, backend:account(AccNo)),
    ?assertEqual(false, backend:pin_valid(AccNo, Pin)),
    ?assertEqual(ok, backend:unblock(AccNo)),
    ?assertMatch(#account{blocked = false}, backend:account(AccNo)),
    ?assertEqual(true, backend:pin_valid(AccNo, Pin)),
    ?assertEqual(ok, backend:stop()).
