%%%=============================================================================
%%% @copyright 2019, Erlang Solutions Ltd
%%% @doc Additional unit tests for the ebank backend_db.
%%% @end
%%%=============================================================================
-module(backend_db_extra_tests).
-copyright("2019, Erlang Solutions Ltd.").

-include_lib("eunit/include/eunit.hrl").
-include_lib("ebank/include/backend.hrl").

block_unblock_test() ->
    DB = backend_db:create_db(),
    AccNo = 1,
    ?assertEqual({error, instance}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(ok, backend_db:new_account(AccNo, "1234", "Donald Duck", DB)),
    ?assertMatch(#account{blocked = false}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(ok, backend_db:block(AccNo, DB)),
    ?assertMatch(#account{blocked = true}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(ok, backend_db:unblock(AccNo, DB)),
    ?assertMatch(#account{blocked = false}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(ok, backend_db:close(DB)).

block_unblock_invalid_account_test() ->
    DB = backend_db:create_db(),
    AccNo = 1,
    ?assertEqual({error, instance}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(ok, backend_db:block(AccNo, DB)),
    ?assertEqual(ok, backend_db:unblock(AccNo, DB)),
    ?assertEqual(ok, backend_db:close(DB)).

blocked_invalid_pin_test() ->
    DB = backend_db:create_db(),
    AccNo = 1,
    Pin = "1234",
    ?assertEqual({error, instance}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(ok, backend_db:new_account(AccNo, Pin, "Donald Duck", DB)),
    ?assertMatch(#account{blocked = false}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(true, backend_db:is_pin_valid(AccNo, Pin, DB)),
    ?assertEqual(ok, backend_db:block(AccNo, DB)),
    ?assertMatch(#account{blocked = true}, backend_db:lookup(AccNo, DB)),
    ?assertEqual(false, backend_db:is_pin_valid(AccNo, Pin, DB)),
    ?assertEqual(ok, backend_db:close(DB)).
