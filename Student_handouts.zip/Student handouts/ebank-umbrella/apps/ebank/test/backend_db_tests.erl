%%%=============================================================================
%%% @copyright 2019, Erlang Solutions Ltd
%%% @doc Unit tests for the ebank backend_db.
%%% @end
%%%=============================================================================
-module(backend_db_tests).
-copyright("2019, Erlang Solutions Ltd.").

-include_lib("eunit/include/eunit.hrl").
-include_lib("ebank/include/backend.hrl").

create_db_test() ->
    Ref = backend_db:create_db(),
    ?assertEqual(accounts, Ref),
    ?assertEqual(set, ets:info(accounts, type)).

lookup_test() ->
    ?assertEqual({error, instance}, backend_db:lookup(1, accounts)).

new_account_test() ->
    Result1 = backend_db:new_account(1, "1234", "Donald Duck", accounts),
    ?assertEqual(ok, Result1),
    Result2 = backend_db:new_account(1, "1234", "Donald Duck", accounts),
    ?assertEqual({error, exists}, Result2).

lookup_by_name_test() ->
    ?assertEqual([], backend_db:lookup_by_name("NoName", accounts)).

close_db_test() ->
    ?assertEqual(ok, backend_db:close(accounts)).

sequence_test() ->
    DB = backend_db:create_db(),
    ?assertEqual(accounts, DB),
    ?assertEqual(ok, backend_db:new_account(1, "1234", "Donald Duck", DB)),
    ?assertEqual(#account{acc_no = 1,
                          balance = 0,
                          pin = "1234",
                          name = "Donald Duck",
                          transactions = []}, backend_db:lookup(1, DB)),
    ?assertEqual(ok, backend_db:credit(1, 100, DB)),
    #account{acc_no = 1,
             balance = 100,
             pin = "1234",
             name = "Donald Duck",
             transactions = [{credit, Timestamp1, 100}]} = backend_db:lookup(1, DB),
    ?assertMatch({{_, _, _}, {_, _, _}}, Timestamp1),
    ?assertEqual(ok, backend_db:credit(1, 100, DB)),
    #account{acc_no = 1,
             balance = 200,
             pin = "1234",
             name = "Donald Duck",
             transactions = [{credit, Timestamp2, 100},
                             {credit, Timestamp1, 100}]} =  backend_db:lookup(1, DB),
    ?assertMatch({{_, _, _}, {_, _, _}}, Timestamp2),
    ?assertEqual(ok, backend_db:debit(1, 50, DB)),
    #account{acc_no = 1,
             balance = 150,
             pin = "1234",
             name = "Donald Duck",
             transactions = [{debit, Timestamp3, 50},
                             {credit, Timestamp2, 100},
                             {credit, Timestamp1, 100}]} = backend_db:lookup(1, DB),
    ?assertMatch({{_, _, _}, {_, _, _}}, Timestamp3),
    ?assertEqual({error, balance},  backend_db:debit(1, 200, DB)),
    ?assertEqual(true, backend_db:is_pin_valid(1, "1234", DB)),
    ?assertEqual(false, backend_db:is_pin_valid(1, "1111", DB)),
    ?assertEqual(ok, backend_db:close(DB)).
