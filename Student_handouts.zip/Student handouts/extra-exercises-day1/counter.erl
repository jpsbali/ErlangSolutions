%% Module counter with API:
%%
%% start_link() -> {ok,CounterPid}.
%% stop(CounterPid) -> ok.
%% add(CounterPid, Number) -> ok.
%% sub(CounterPid, Number) -> ok.
%% get(CounterPid) -> Count.
%%
%% Test:
%% sys:get_state(CounterPid).
%% sys:trace(CounterPid, true).

-module(counter).

-behaviour(gen_server).

%% User API.
-export([start_link/0,stop/1,add/2,sub/2,get/1]).
%% Behaviour callbacks.
-export([init/1,handle_call/3,handle_cast/2,handle_info/2,terminate/2]).

%% API.
start_link() ->
    gen_server:start_link(counter, [], []).

stop(CP) ->
    gen_server:call(CP, stop).

add(CP, Number) ->
    gen_server:cast(CP, {add,Number}).

sub(CP, Number) ->
    gen_server:cast(CP, {sub,Number}).

get(CP) ->
    gen_server:call(CP, get).

%% Callbacks

init(_) ->
    {ok,0}.

handle_call(get, _From, Counter) ->
    {reply,Counter,Counter};
handle_call(stop, _From, Counter) ->
    {stop,normal,ok,Counter}.

handle_cast({add,Number}, Counter) ->
    NewCounter = Counter + Number,
    {noreply,NewCounter};
handle_cast({sub,Number}, Counter) ->
    NewCounter = Counter - Number,
    {noreply,NewCounter}.

handle_info(_Msg, Counter) ->
    %% Ignore everything else.
    {noreply,Counter}.
    
terminate(_Reason, _Counter) ->
    ok.
