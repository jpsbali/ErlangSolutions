%% A light switch in a state machine.
%%
%% Module light_switch, 2 states light_on and light_off.
%%
%% API
%%
%% start_link() -> {ok,SwitchPid}.
%% stop(SwitchPid) -> ok.
%% click(SwitchPid) -> on | off.

-module(light_switch).

-behaviour(gen_statem).

%% User API.
-export([start_link/0,stop/1,click/1]).
%% Behaviour callbacks.
-export([init/1,callback_mode/0,terminate/3,light_on/3,light_off/3]).

%% API.

start_link() ->
    gen_statem:start_link(light_switch, [], []).

stop(SwitchPid) ->
    gen_statem:cast(SwitchPid, stop).

click(SwitchPid) ->
    gen_statem:call(SwitchPid, click).

%% Callbacks.

init(_) ->
    {ok,light_off,[]}.                          %We have no state

callback_mode() ->
    state_functions.

light_off({call,From}, click, Data) ->
    {next_state,light_on,Data,[{reply,From,on}]};
light_off(cast, stop, Data) ->
    {stop,normal,Data};
light_off(info, _Msg, Data) ->
    %% Ignore everything else and stay in the same state.
    {keep_state,Data}.

light_on({call,From}, click, Data) ->
    {next_state,light_off,Data,[{reply,From,off}]};
light_on(cast, stop, Data) ->
    {stop,normal,Data};
light_on(info, _Msg, Data) ->
    %% Ignore everything else and stay in the same state.
    {keep_state,Data}.

terminate(_Reason, _State, _Data) ->
    ok.
